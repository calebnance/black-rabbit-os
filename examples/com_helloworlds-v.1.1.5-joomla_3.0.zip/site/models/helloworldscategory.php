<?php
/*------------------------------------------------------------------------
# helloworldscategory.php - Hello World Component
# ------------------------------------------------------------------------
# author    Caleb Nance
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.codelydia.com
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');
// import the Joomla modellist library
jimport('joomla.application.component.modellist');

/**
 * Helloworlds Cateory Model for Helloworlds Component
 */
class HelloworldsModelhelloworldscategory extends JModelList
{
	/**
	 * Method to build an SQL query to load the list data.
	 *
	 * @return      string  An SQL query
	 */
	protected function getListQuery()
	{
		$pk = JRequest::getInt('id');

		// Create a new query object.
		$db = JFactory::getDBO();
		$query	= $db->getQuery(true);
		// Select some fields
		$query->select('*');
		// From the products_product table
		$query->from('#__helloworlds_helloworld');
		$query->where('category="' . $pk . '"');

		return $query;
	}
}
?>