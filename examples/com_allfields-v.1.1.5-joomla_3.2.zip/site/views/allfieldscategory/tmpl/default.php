<?php
/*------------------------------------------------------------------------
# default.php - All Fields Component
# ------------------------------------------------------------------------
# author    Caleb Nance
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.codelydia.com
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
<h1 class="page-header"><?php echo $this->document->title; ?></h1>
<div id="category-allfields-content">
<?php foreach($this->items as $item){ ?>
	<p><strong>Title</strong>: <?php echo $item->title; ?></p>
	<p><strong>Category</strong>: <?php echo $item->category; ?></p>
	<p><strong>Date Selector</strong>: <?php echo $item->dateselector; ?></p>
	<p><strong>Content Editor</strong>: <?php echo $item->contenteditor; ?></p>
	<p><strong>Text Area</strong>: <?php echo $item->textarea; ?></p>
	<p><strong>Radio</strong>: <?php echo $item->radio; ?></p>
	<?php if($item->imageupload){ ?>
		<p><strong>Image Upload</strong>: <img src="images/com_allfields/<?php echo $item->imageupload; ?>" /></p>
	<?php } ?>
<?php } ?>
</div>