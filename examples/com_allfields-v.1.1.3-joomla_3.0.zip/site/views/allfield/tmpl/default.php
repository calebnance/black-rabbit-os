<?php
/*------------------------------------------------------------------------
# default.php - All Fields Component
# ------------------------------------------------------------------------
# author    Caleb Nance
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.codelydia.com
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?>
<div id="allfields-content">
	<p><strong>Title</strong>: <?php echo $this->item->title; ?></p>
	<p><strong>Category</strong>: <?php echo $this->item->category; ?></p>
	<p><strong>Date Selector</strong>: <?php echo $this->item->dateselector; ?></p>
	<p><strong>Content Editor</strong>: <?php echo $this->item->textarea; ?></p>
	<?php if($this->item->imageupload){ ?>
		<p><strong>Text Area</strong>: <img src="images/com_allfields/<?php echo $this->item->imageupload; ?>" /></p>
	<?php } ?>
	<p><strong>Image Upload</strong>: <?php echo $this->item->numbers; ?></p>
	<p><strong>Numbers</strong>: <?php echo $this->item->published; ?></p>
	<p><strong>Published</strong>: <?php echo $this->item->; ?></p>
</div>