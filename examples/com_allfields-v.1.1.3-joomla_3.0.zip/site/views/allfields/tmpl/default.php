<?php
/*------------------------------------------------------------------------
# default.php - All Fields Component
# ------------------------------------------------------------------------
# author    Caleb Nance
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.codelydia.com
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

// Connect to database
$db = JFactory::getDBO();
jimport('joomla.filter.output');
?>
<div id="allfields-allfields">
	<?php foreach($this->items as $item){ ?>
		<?php
		$item->category = $db->setQuery('SELECT #__categories.title FROM #__categories WHERE #__categories.id = "'.$item->category.'"')->loadResult();
		if(empty($item->alias)){
			$item->alias = $item->title;
		};
		$item->alias = JFilterOutput::stringURLSafe($item->alias);
		$item->linkURL = JRoute::_('index.php?option=com_allfields&view=allfield&id='.$item->id.':'.$item->alias);
		?>
		<p><strong>Title</strong>: <a href="<?php echo $item->linkURL; ?>"><?php echo $item->title; ?></a></p>
		<p><strong>Category</strong>: <?php echo $item->category; ?></p>
		<p><strong>Date Selector</strong>: <?php echo $item->dateselector; ?></p>
		<p><strong>Content Editor</strong>: <?php echo $item->textarea; ?></p>
		<?php if($item->imageupload){ ?>
			<p><strong>Text Area</strong>: <img src="images/com_allfields/thumb/<?php echo $item->imageupload; ?>" /></p>
		<?php } ?>
		<p><strong>Image Upload</strong>: <?php echo $item->numbers; ?></p>
		<p><strong>Numbers</strong>: <?php echo $item->published; ?></p>
		<p><strong>Published</strong>: <?php echo $item->; ?></p>
		<p><strong>Link URL</strong>: <a href="<?php echo $item->linkURL; ?>">Go to page</a> - <?php echo $item->linkURL; ?></p>
		<br /><br />
	<?php }; ?>
</div>
