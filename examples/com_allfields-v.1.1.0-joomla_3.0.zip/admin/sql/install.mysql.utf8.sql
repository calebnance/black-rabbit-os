CREATE TABLE IF NOT EXISTS `#__allfields_allfield` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(256) NOT NULL,
  `category` int(11) NOT NULL DEFAULT '0',
  `dateselector` DATE NOT NULL,
  `contenteditor` TEXT NOT NULL DEFAULT '',
  `textarea` TEXT NOT NULL DEFAULT '',
  `imageupload` varchar(256) NOT NULL,
  `numbers` int(11) NOT NULL DEFAULT '0',
  `integer` int(11) NOT NULL DEFAULT '0',
  `radiolist` varchar(256) NOT NULL,
  `user_created` int(11) NOT NULL DEFAULT '0',
  `user_modified` int(11) NOT NULL DEFAULT '0',
  `date_created` DATETIME NOT NULL,
  `date_modified` DATETIME NOT NULL,
  `checked_out` int(11) NOT NULL,
  `checked_out_time` DATETIME NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;