<?php
/*------------------------------------------------------------------------
# default.php - All Fields Component
# ------------------------------------------------------------------------
# author    Caleb Nance
# copyright Copyright (C) 2013. All Rights Reserved
# license   GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
# website   www.codelydia.com
-------------------------------------------------------------------------*/

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

?><div id="allfields-content">
	<p><strong>Title</strong>: <?php echo $this->item->title; ?></p>
	<p><strong>Category</strong>: <?php echo $this->item->category; ?></p>
	<p><strong>Date Selector</strong>: <?php echo $this->item->dateselector; ?></p>
	<p><strong>Checked</strong>: <?php echo $this->item->checked; ?></p>
	<p><strong>Content Editor</strong>: <?php echo $this->item->contenteditor; ?></p>
	<p><strong>Text Area</strong>: <?php echo $this->item->textarea; ?></p>
	<p><strong>Image Upload</strong>: <?php echo $this->item->imageupload; ?></p>
	<p><strong>Numbers</strong>: <?php echo $this->item->numbers; ?></p>
	<p><strong>Integer</strong>: <?php echo $this->item->integer; ?></p>
	<p><strong>Radio List</strong>: <?php echo $this->item->radiolist; ?></p>
</div>