/**
 *	helloworld : Validate
 *	Filename : helloworld.js
 *
 *	Author : Caleb
 *	Component : Hello World
 *
 *	Copyright : Copyright (C) 2019. All Rights Reserved
 *	License : GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 *
 **/
window.addEvent('domready', function() {
});